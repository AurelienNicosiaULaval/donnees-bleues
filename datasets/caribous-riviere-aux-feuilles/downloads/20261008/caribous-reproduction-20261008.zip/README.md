# Caribous de la Rivière-aux-Feuilles

Version du 8 octobre 2026 publiée par Données bleues.

1 911 positions GPS, 52 individus, 319 segments sélectionnés entre le 20 avril
2007 et le 19 mai 2014 dans le nord du Québec. Les six fichiers originaux ont
été téléchargés depuis [Zenodo](https://zenodo.org/records/4958113) ; chaque
empreinte MD5 correspond à celle du [dépôt Dryad](https://doi.org/10.5061/dryad.4k275).
Licence des données originales : CC0.

Les segments concernent les traversées sur glace, à la nage et les
contournements de grands plans d'eau. Ils ne constituent pas le suivi complet
des migrations. Voir `rapport.html` et `dictionnaire.md` pour les limites,
notamment le fuseau horaire, le datum des GPS et une incohérence d'identifiant
conservée dans six lignes.

## Organisation

- `donnees_originales/` : les six fichiers téléchargés, intacts ;
- `donnees_preparees/` : positions, pas, segments, tables complémentaires en CSV et données spatiales en GeoPackage ;
- `scripts/` : acquisition vérifiée et préparation en R ;
- `provenance.json` : URL, dates d’acquisition et empreintes des originaux ;
- `verification/` : créé lors d’une nouvelle préparation pour conserver les contrôles ;
- `rapport.qmd`, `rapport.html`, `figures/` : rapport reproductible et carte.

## Utiliser dans R

Depuis le dossier extrait, installer les dépendances si elles sont absentes :

```r
install.packages(c("readxl", "readr", "dplyr", "tidyr", "sf", "ggplot2",
                   "leaflet", "jsonlite", "digest", "knitr"))
```

Pour une lecture sans ambiguïté des dates/heures et identifiants :

```r
library(readr)
library(dplyr)

# Exécuter depuis le dossier du jeu de données.
positions <- read_csv(
  "donnees_preparees/positions_caribous.csv",
  col_types = cols(
    id_individu_source = col_character(),
    id_annee_source = col_character(),
    id_depuis_idyr = col_character(),
    date_source = col_date(),
    heure_source = col_character(),
    date_heure_source = col_character()
  )
)

positions |>
  group_by(type_deplacement) |>
  summarise(n_positions = n(), n_individus = n_distinct(id_individu_source),
            n_segments = n_distinct(cle_segment), .groups = "drop")
```

Pour régénérer les données et le rapport :

```bash
Rscript --vanilla scripts/acquerir_donnees.R .
Rscript --vanilla scripts/preparer_caribous.R .
quarto render rapport.qmd
```

La préparation et le rendu fonctionnent à partir des fichiers locaux.
L'acquisition nécessite Internet. Quarto est nécessaire pour le rendu HTML,
mais pas pour importer les CSV. Les scripts conservent les fichiers originaux déjà présents.

La carte interactive comporte un fond OpenStreetMap, chargé par Internet
lorsque le rapport est ouvert. Les déplacements et les contours des plans
d'eau sont embarqués dans le HTML ; les tuiles du fond cartographique ne sont
pas incluses dans l'archive.

Les licences du code et de la documentation sont incluses; voir `DATA_LICENSE.md`.
La carte autonome s’ouvre dans `carte.html`.

## Citer

Leblond, M., St-Laurent, M.-H. et Côté, S. D. (2017). Data from: Caribou, water,
and ice: fine-scale movements of a migratory arctic ungulate in the context of
climate change. Dryad. https://doi.org/10.5061/dryad.4k275.

Article associé : Leblond et al. (2016), Movement Ecology, 4, 14.
https://doi.org/10.1186/s40462-016-0079-4.

Les distances, vitesses et angles du dossier préparé sont des calculs
descriptifs supplémentaires. Ils ne sont pas des résultats validés des modèles
de l'article.
