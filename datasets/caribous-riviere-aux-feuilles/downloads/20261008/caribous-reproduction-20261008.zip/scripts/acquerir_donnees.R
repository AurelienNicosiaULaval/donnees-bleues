# Acquisition de la copie publique Zenodo du dépôt 10.5061/dryad.4k275.
# Depuis le dossier du jeu : Rscript --vanilla scripts/acquerir_donnees.R .
library(jsonlite)
library(digest)

arguments <- commandArgs(trailingOnly = TRUE)
racine <- if (length(arguments)) arguments[1] else getwd()
racine <- normalizePath(racine, mustWork = TRUE)
dir.create(file.path(racine, "donnees_originales"), showWarnings = FALSE)
dir.create(file.path(racine, "sources_archivees"), showWarnings = FALSE)
dir.create(file.path(racine, "verification"), showWarnings = FALSE)

lire_json <- function(url) {
  fichier <- tempfile(fileext = ".json")
  on.exit(unlink(fichier))
  download.file(url, fichier, mode = "wb", quiet = TRUE)
  fromJSON(fichier, simplifyVector = FALSE)
}

record <- lire_json("https://zenodo.org/api/records/4958113")
write_json(record, file.path(racine, "sources_archivees/zenodo_4958113.json"),
           pretty = TRUE, auto_unbox = TRUE)
ids_dryad <- c("IceCross_Data.xlsx" = 28081, "WaterCross_Data.xlsx" = 28082,
               "Detour_Data.xlsx" = 28083, "Ice-Water_Proportion_Data.xlsx" = 28084,
               "NAO_AO_Data.xlsx" = 28085, "Lakes_shapefile.zip" = 28086)
stopifnot(setequal(vapply(record$files, `[[`, "", "key"), names(ids_dryad)))

provenance <- lapply(record$files, function(f) {
  cible <- file.path(racine, "donnees_originales", f$key)
  url <- f$links$self
  md5_attendu <- sub("^md5:", "", f$checksum)
  if (!file.exists(cible)) {
    temporaire <- tempfile(fileext = paste0("_", f$key))
    download.file(url, temporaire, mode = "wb", quiet = TRUE)
    stopifnot(digest(temporaire, algo = "md5", file = TRUE) == md5_attendu)
    stopifnot(file.copy(temporaire, cible, overwrite = FALSE))
    unlink(temporaire)
  }
  md5_observe <- digest(cible, algo = "md5", file = TRUE)
  stopifnot(md5_observe == md5_attendu)
  api_dryad <- paste0("https://datadryad.org/api/v2/files/", ids_dryad[[f$key]])
  original <- lire_json(api_dryad)
  stopifnot(original$digestType == "md5", original$digest == md5_observe,
            original$size == file.info(cible)$size)
  write_json(original, file.path(racine, "sources_archivees",
             paste0("dryad_file_", ids_dryad[[f$key]], ".json")),
             pretty = TRUE, auto_unbox = TRUE)
  list(fichier = f$key, url = url,
       verification_utc = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"),
       taille_octets = unname(file.info(cible)$size), md5 = md5_observe,
       sha256 = digest(cible, algo = "sha256", file = TRUE),
       correspondance_md5_dryad = TRUE, dryad_api = api_dryad)
})
write_json(list(dataset_doi = "10.5061/dryad.4k275",
                copie_publique = "https://zenodo.org/records/4958113",
                licence = record$metadata$license, fichiers = provenance),
           file.path(racine, "verification/provenance_reacquisition.json"),
           pretty = TRUE, auto_unbox = TRUE)
message("Six fichiers présents et vérifiés avec les empreintes Zenodo et Dryad.")
