# Exécuter depuis le dossier extrait après installation des packages du README.
library(htmlwidgets)
source("scripts/preparer_caribous.R", encoding = "UTF-8", local = TRUE)
saveWidget(carte, "carte.html", selfcontained = TRUE,
           title = "Caribous de la Rivière-aux-Feuilles", background = "white")
