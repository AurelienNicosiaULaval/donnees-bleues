# Préparation descriptive du dépôt de Leblond, St-Laurent et Côté (2017).
# Depuis le dossier du jeu : Rscript --vanilla scripts/preparer_caribous.R .
# Dans R : setwd("/chemin/du/dossier"); source("scripts/preparer_caribous.R")
library(readxl)
library(readr)
library(dplyr)
library(tidyr)
library(sf)
library(ggplot2)
library(leaflet)
library(jsonlite)
library(digest)

arguments <- commandArgs(trailingOnly = TRUE)
# Quarto peut ajouter des arguments : son exécution utilise le dossier courant.
racine <- if (length(arguments) && dir.exists(arguments[1])) arguments[1] else getwd()
racine <- normalizePath(racine, mustWork = TRUE)
for (d in c("donnees_preparees", "verification", "figures")) {
  dir.create(file.path(racine, d), showWarnings = FALSE)
}
brut <- file.path(racine, "donnees_originales")
sortie <- file.path(racine, "donnees_preparees")

# Les empreintes sont celles de l'acquisition initiale, conservée dans provenance.json.
provenance <- fromJSON(file.path(racine, "provenance.json"))
for (i in seq_len(nrow(provenance$fichiers))) {
  f <- provenance$fichiers[i, ]
  stopifnot(digest(file.path(brut, f$fichier), algo = "sha256", file = TRUE) == f$sha256)
}

fichiers <- c("IceCross_Data.xlsx", "WaterCross_Data.xlsx", "Detour_Data.xlsx")
types <- c("Traversée sur glace", "Traversée à la nage", "Contournement")
colonnes <- c("ID", "LATITUDE", "LONGITUDE", "YEAR", "DATE", "TIME", "IDYR",
              "JULIAN DATE", "MODIS PERIOD", "PERIOD CODE", "STATE", "BEHAVIOR",
              "SEGMENT", "TYPE")
tables <- lapply(seq_along(fichiers), function(i) {
  x <- read_excel(file.path(brut, fichiers[i]))
  stopifnot(identical(names(x), colonnes))
  x |> mutate(fichier_source = fichiers[i], ligne_excel = row_number() + 1L,
              type_deplacement = types[i])
})
sources_gps <- bind_rows(tables)

# DATE est une date civile. TIME n'a pas de fuseau documenté.
# On conserve une chaîne sans suffixe UTC et calcule les écarts d'horloge civile.
positions <- sources_gps |>
  transmute(id_individu_source = sprintf("%.0f", ID),
            id_annee_source = IDYR,
            id_depuis_idyr = sub("_[0-9]{4}$", "", IDYR),
            id_coherent = id_individu_source == id_depuis_idyr,
            segment_source = as.integer(SEGMENT),
            cle_segment = paste0("RAF_", as.integer(SEGMENT)),
            type_deplacement,
            latitude = LATITUDE, longitude = LONGITUDE,
            annee_source = as.integer(YEAR),
            date_source = as.Date(DATE), heure_source = TIME,
            date_heure_source = paste0(format(date_source, "%Y-%m-%d"), "T", TIME),
            jour_annee_source = as.integer(`JULIAN DATE`),
            periode_modis_source = as.integer(`MODIS PERIOD`),
            code_periode_source = `PERIOD CODE`,
            etat_source = STATE, comportement_source = BEHAVIOR,
            type_plan_eau_source = TYPE, fichier_source, ligne_excel) |>
  mutate(temps_civil_secondes = as.numeric(date_source) * 86400 +
           as.numeric(as.difftime(heure_source, format = "%H:%M:%S", units = "secs"))) |>
  arrange(segment_source, temps_civil_secondes) |>
  group_by(cle_segment) |>
  mutate(rang_dans_segment = row_number()) |>
  ungroup()

controle_segments <- positions |>
  group_by(cle_segment) |>
  summarise(n_positions = n(), n_individus = n_distinct(id_individu_source),
            n_idyr = n_distinct(id_annee_source), n_types = n_distinct(type_deplacement),
            .groups = "drop")
doublons <- positions |>
  count(id_individu_source, date_heure_source, name = "n") |>
  filter(n > 1L)
stopifnot(nrow(doublons) == 0L,
          all(controle_segments$n_individus == 1L),
          all(controle_segments$n_types == 1L),
          all(controle_segments$n_positions >= 3L),
          !anyNA(positions),
          all(abs(positions$latitude) <= 90), all(abs(positions$longitude) <= 180),
          all(positions$annee_source == as.integer(format(positions$date_source, "%Y"))),
          all(positions$jour_annee_source == as.integer(format(positions$date_source, "%j"))))

# Hypothèse explicite : coordonnées GPS traitées comme WGS84 (EPSG:4326).
# Le dépôt n'indique pas le datum des points. Celui des lacs est fourni dans le .prj.
points_geo <- st_as_sf(positions |> select(-temps_civil_secondes), coords = c("longitude", "latitude"),
                       crs = 4326, remove = FALSE)
points_lambert <- st_transform(points_geo, 32198)
xy <- st_coordinates(points_lambert)
positions$x_lambert_m <- xy[, 1]
positions$y_lambert_m <- xy[, 2]

calcul_pas <- positions |>
  group_by(cle_segment) |>
  mutate(longitude_depart = lag(longitude), latitude_depart = lag(latitude),
         date_heure_depart = lag(date_heure_source),
         dx = x_lambert_m - lag(x_lambert_m),
         dy = y_lambert_m - lag(y_lambert_m),
         duree_h = (temps_civil_secondes - lag(temps_civil_secondes)) / 3600,
         distance_ligne_droite_m = sqrt(dx^2 + dy^2),
         vitesse_pas_m_h = distance_ligne_droite_m / duree_h,
         cap_rad = atan2(dy, dx),
         angle_rotation_abs_deg = if_else(
           distance_ligne_droite_m > 0 & lag(distance_ligne_droite_m) > 0,
           abs(atan2(sin(cap_rad - lag(cap_rad)), cos(cap_rad - lag(cap_rad)))) * 180 / pi,
           NA_real_),
         intervalle_sup_13_1h = duree_h > 13.1) |>
  ungroup()
pas <- calcul_pas |>
  filter(rang_dans_segment > 1L) |>
  select(cle_segment, segment_source, id_individu_source, type_deplacement,
         rang_arrivee = rang_dans_segment, date_heure_depart,
         date_heure_arrivee = date_heure_source,
         longitude_depart, latitude_depart, longitude_arrivee = longitude,
         latitude_arrivee = latitude, duree_h, distance_ligne_droite_m,
         vitesse_pas_m_h, angle_rotation_abs_deg, intervalle_sup_13_1h)
stopifnot(all(pas$duree_h > 0), all(is.finite(pas$vitesse_pas_m_h)))

segments <- calcul_pas |>
  group_by(cle_segment, segment_source, id_individu_source, type_deplacement) |>
  summarise(id_annees_source = paste(sort(unique(id_annee_source)), collapse = ";"),
            n_positions = n(), n_pas = n() - 1L,
            date_heure_debut = first(date_heure_source),
            date_heure_fin = last(date_heure_source),
            duree_totale_h = sum(duree_h, na.rm = TRUE),
            distance_cumulee_lignes_droites_m = sum(distance_ligne_droite_m, na.rm = TRUE),
            vitesse_moyenne_des_pas_m_h = mean(vitesse_pas_m_h, na.rm = TRUE),
            intervalle_min_h = min(duree_h, na.rm = TRUE),
            intervalle_max_h = max(duree_h, na.rm = TRUE),
            contient_intervalle_sup_13_1h = any(intervalle_sup_13_1h, na.rm = TRUE),
            .groups = "drop")
resume_types <- positions |>
  group_by(type_deplacement) |>
  summarise(positions = n(), individus = n_distinct(id_individu_source),
            segments = n_distinct(cle_segment),
            date_debut = min(date_source), date_fin = max(date_source),
            .groups = "drop") |>
  left_join(pas |>
    group_by(type_deplacement) |>
    summarise(pas = n(), intervalle_median_h = median(duree_h),
              intervalle_max_h = max(duree_h), .groups = "drop"),
    by = "type_deplacement")

write_csv(positions |> select(-temps_civil_secondes), file.path(sortie, "positions_caribous.csv"))
write_csv(pas, file.path(sortie, "pas_caribous.csv"))
write_csv(segments, file.path(sortie, "segments_caribous.csv"))
write_csv(resume_types, file.path(sortie, "resume_types.csv"))
write_csv(positions |> filter(!id_coherent) |>
            select(id_individu_source, id_annee_source, fichier_source, ligne_excel),
          file.path(racine, "verification/identifiants_incoherents.csv"))
manquants <- bind_rows(lapply(seq_along(tables), function(i) {
  tibble(fichier = fichiers[i], variable = colonnes,
         n_manquants = vapply(tables[[i]][colonnes], function(x) sum(is.na(x)), 0L))
}))
write_csv(manquants, file.path(racine, "verification/manquants_positions.csv"))

# Conversions des deux fichiers complémentaires, sans attribuer d'année aux
# blocs MODIS : le classeur Ice-Water ne fournit pas de colonne année.
glace <- read_excel(file.path(brut, "Ice-Water_Proportion_Data.xlsx"))
oscillations <- read_excel(file.path(brut, "NAO_AO_Data.xlsx"))
write_csv(glace |> mutate(ligne_excel = row_number() + 1L),
          file.path(sortie, "glace_eau_table_source.csv"))
write_csv(oscillations |> mutate(ligne_excel = row_number() + 1L),
          file.path(sortie, "nao_ao_table_source.csv"))

# Les fichiers extraits sont des copies ; l'archive source reste intacte.
dossier_lacs <- file.path(sortie, "lacs_shapefile")
dir.create(dossier_lacs, showWarnings = FALSE)
unzip(file.path(brut, "Lakes_shapefile.zip"), exdir = dossier_lacs)
lacs <- st_read(file.path(dossier_lacs, "Lakes_shapefile.shp"), quiet = TRUE)
stopifnot(st_crs(lacs)$epsg == 32198, all(st_is_valid(lacs)))
lignes <- lapply(split(positions, positions$cle_segment), function(x) {
  st_linestring(as.matrix(x[, c("x_lambert_m", "y_lambert_m")]))
})
segments_geo <- st_sf(segments,
  geometry = st_sfc(lignes[segments$cle_segment], crs = 32198))
gpkg <- file.path(sortie, "caribous_et_lacs.gpkg")
st_write(points_geo, gpkg, layer = "positions_hypothese_wgs84", delete_layer = TRUE, quiet = TRUE)
st_write(segments_geo, gpkg, layer = "segments_interpolation_lineaire", delete_layer = TRUE, quiet = TRUE)
st_write(lacs, gpkg, layer = "plans_eau_source", delete_layer = TRUE, quiet = TRUE)

couleurs <- c("Traversée sur glace" = "#087A94", "Traversée à la nage" = "#D26B29",
              "Contournement" = "#724E91")
bornes <- st_bbox(points_lambert)
carte_statique <- ggplot() +
  geom_sf(data = lacs, fill = "#d8e8f0", color = "#a9c6d5", linewidth = 0.15) +
  geom_sf(data = segments_geo, aes(color = type_deplacement), linewidth = 0.4, alpha = 0.75) +
  scale_color_manual(values = couleurs, name = NULL) +
  coord_sf(xlim = bornes[c("xmin", "xmax")] + c(-15000, 15000),
           ylim = bornes[c("ymin", "ymax")] + c(-15000, 15000), expand = FALSE) +
  labs(title = "Caribous de la Rivière-aux-Feuilles",
       subtitle = "319 segments sélectionnés autour des plans d'eau, 2007 à 2014",
       caption = "Sources : Leblond et al. (2017), Dryad / Zenodo.\nTraits : interpolation entre GPS dans un même segment. Datum des GPS : hypothèse WGS84.") +
  theme_minimal(base_size = 12) +
  theme(legend.position = "bottom", panel.grid.major = element_line(color = "#ededed"))
ggsave(file.path(racine, "figures/carte_caribous.png"), carte_statique,
       width = 10, height = 8, dpi = 180)

segments_web <- st_transform(segments_geo, 4326)
segments_web$infobulle <- paste0(segments_web$type_deplacement,
  "<br>Segment ", segments_web$segment_source,
  "<br>Caribou : ", segments_web$id_individu_source,
  "<br>", segments_web$date_heure_debut, " à ", segments_web$date_heure_fin,
  "<br>", segments_web$n_positions, " positions",
  "<br>Distance par lignes droites : ",
  round(segments_web$distance_cumulee_lignes_droites_m / 1000, 1), " km",
  "<br>Intervalle maximal : ", round(segments_web$intervalle_max_h, 2), " h",
  "<br>Fuseau horaire non documenté")
carte <- leaflet(options = leafletOptions(preferCanvas = TRUE), height = 570) |>
  addTiles(urlTemplate = "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
           attribution = '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
           options = tileOptions(maxZoom = 19)) |>
  addPolygons(data = st_transform(lacs, 4326), color = "#97b5c8", weight = 1,
              fillColor = "#dceaf2", fillOpacity = 0.8, group = "Plans d'eau")
for (categorie in types) {
  traces <- segments_web[segments_web$type_deplacement == categorie, ]
  pts <- positions[positions$type_deplacement == categorie, ]
  carte <- carte |>
    addPolylines(data = traces, color = couleurs[[categorie]], weight = 3,
                 opacity = 0.8, popup = traces$infobulle, group = categorie) |>
    addCircleMarkers(lng = pts$longitude, lat = pts$latitude, radius = 1.5,
                     color = couleurs[[categorie]], weight = 0.5, fillOpacity = 0.65,
                     popup = paste0("Caribou ", pts$id_individu_source,
                       "<br>Segment ", pts$segment_source,
                       "<br>", pts$date_heure_source,
                       "<br>Code STATE : ", pts$etat_source),
                     group = categorie)
}
carte <- carte |>
  addLayersControl(overlayGroups = c("Plans d'eau", types),
                   options = layersControlOptions(collapsed = FALSE)) |>
  addScaleBar(position = "bottomleft") |>
  fitBounds(min(positions$longitude), min(positions$latitude),
            max(positions$longitude), max(positions$latitude))

audit <- list(dataset = "10.5061/dryad.4k275", n_positions = nrow(positions),
  n_individus = n_distinct(positions$id_individu_source),
  n_individus_annees = n_distinct(positions$id_annee_source),
  n_segments = nrow(segments), n_pas = nrow(pas),
  date_debut = as.character(min(positions$date_source)),
  date_fin = as.character(max(positions$date_source)),
  n_doublons_id_horodatage = nrow(doublons), n_valeurs_manquantes_positions = 0L,
  n_positions_id_incoherent = sum(!positions$id_coherent),
  n_identifiants_incoherents = n_distinct(positions$id_individu_source[!positions$id_coherent]),
  intervalle_min_h = min(pas$duree_h), intervalle_max_h = max(pas$duree_h),
  n_pas_intervalle_sup_13_1h = sum(pas$intervalle_sup_13_1h),
  n_distances_nulles = sum(pas$distance_ligne_droite_m == 0),
  n_lignes_glace_eau = nrow(glace), n_lignes_nao_ao = nrow(oscillations),
  fuseau_horaire = "non documenté",
  datum_points = "non documenté ; hypothèse WGS84 pour carte et distances",
  crs_lacs_epsg = st_crs(lacs)$epsg,
  calculs_distances = "Euclidiens, après projection NAD83 / Québec Lambert EPSG:32198",
  calculs_temps = "Différences d'horloge civile ; aucune conversion en UTC",
  execution_utc = format(Sys.time(), "%Y-%m-%dT%H:%M:%SZ", tz = "UTC"))
write_json(audit, file.path(racine, "verification/audit.json"),
           pretty = TRUE, auto_unbox = TRUE, digits = 12)
writeLines(capture.output(sessionInfo()), file.path(racine, "verification/sessionInfo.txt"))
print(resume_types)
message(nrow(positions), " positions ; ", n_distinct(positions$id_individu_source),
        " individus ; ", nrow(segments), " segments ; ", nrow(pas), " pas.")
