## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

VILLE DE QUÉBEC. Permis délivrés à la Ville de Québec, [Jeu de données], dans Données Québec, 2025, mis à jour le 08 novembre 2026. [https://www.donneesquebec.ca/recherche/dataset/permis-delivres-ville-de-quebec], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/permis-delivres-ville-de-quebec).

VILLE DE QUÉBEC. Empreintes des bâtiments, [Jeu de données], dans Données Québec, 2022, mis à jour le 01 novembre 2026. [https://www.donneesquebec.ca/recherche/dataset/empreintes-des-batiments], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/empreintes-des-batiments).

VILLE DE QUÉBEC. Quartiers, [Jeu de données], dans Données Québec, 2012, mis à jour le 08 novembre 2026. [https://www.donneesquebec.ca/recherche/dataset/vque_9], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/vque_9).
