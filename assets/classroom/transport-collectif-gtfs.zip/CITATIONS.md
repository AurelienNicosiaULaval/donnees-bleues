## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

LE RÉSEAU DE TRANSPORT DE LA CAPITALE. RTC : GTFS /arrêts et les parcours, [Jeu de données], dans Données Québec, 2017, mis à jour le 26 juin 2023. [https://www.donneesquebec.ca/recherche/dataset/rtc-gtfs-arrets-et-les-parcours], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/rtc-gtfs-arrets-et-les-parcours).
