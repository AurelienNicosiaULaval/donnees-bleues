# Suivi de la qualité de l'eau du fleuve et des rivières

Les CSV préparés sont inclus. Le script fonctionne hors ligne après installation des packages.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Conserver les sous-dossiers de données à leur place.
5. Ouvrir datasets/suivi-rivieres-fleuve/activite-courte.R ou activite-longue.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://aureliennicosiaulaval.github.io/donnees-bleues/datasets/suivi-rivieres-fleuve/fiche.html

## Source et réutilisation

Producteur : Données Québec / MELCCFP
Source : https://www.donneesquebec.ca/recherche/dataset/suivi-physicochimique-des-rivieres-et-du-fleuve
Conditions : https://creativecommons.org/licenses/by/4.0/deed.fr
Préparation : 2026-09-05T11:05:12Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.

Les licences des producteurs tiers s’appliquent à leurs données. Voir la page À propos du site pour les conditions propres aux textes et au code de Données bleues.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.
