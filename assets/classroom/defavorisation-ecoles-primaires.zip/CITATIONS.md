## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

MINISTÈRE DE L'ÉDUCATION ET MINISTÈRE DE L'ENSEIGNEMENT SUPÉRIEUR. Indices de défavorisation, [Jeu de données], dans Données Québec, 2020, mis à jour le 03 juillet 2026. [https://www.donneesquebec.ca/recherche/dataset/indices-de-defavorisation], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/indices-de-defavorisation).
