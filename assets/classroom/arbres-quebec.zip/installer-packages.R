# À exécuter une fois avec Internet avant la séance.
packages <- c("cli", "curl", "DBI", "digest", "dplyr", "fs", "ggplot2", "htmltools", "httr2", "janitor", "jsonlite", "lubridate", "purrr", "readr", "readxl", "RSQLite", "sf", "stringr", "tibble", "tidyr", "xml2")
absents <- setdiff(packages, rownames(installed.packages()))
if (length(absents)) install.packages(absents, repos = "https://cloud.r-project.org")
stopifnot(all(vapply(packages, requireNamespace, logical(1), quietly = TRUE)))
