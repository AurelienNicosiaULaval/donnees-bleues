# Arbres du Québec : quatre espèces forestières

Les CSV préparés sont inclus. Le script fonctionne hors ligne après installation des packages.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Conserver les sous-dossiers de données à leur place.
5. Ouvrir datasets/arbres-quebec/activite-courte.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://aureliennicosiaulaval.github.io/donnees-bleues/datasets/arbres-quebec/fiche.html

## Source et réutilisation

Producteur : MRNF / PET5 ; sélection pédagogique par Aurélien Nicosia ; taxonomie VASCAN
Source : https://github.com/AurelienNicosiaULaval/arbres_quebec/releases/tag/v1.0.0
Conditions : https://creativecommons.org/licenses/by/4.0/deed.fr
Attributions et documentation incluses : datasets/arbres-quebec/DATA_LICENSES.md, datasets/arbres-quebec/LICENCE-SOURCE.md, datasets/arbres-quebec/DICTIONNAIRE.md.
Préparation : 2026-09-05T23:31:53Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.

Le code original de Données bleues est sous licence MIT (voir LICENSE). Les textes et activités originales sont sous CC BY 4.0 (voir LICENCE-CONTENUS.md). Les données et autres contenus de tiers conservent les conditions de leurs producteurs indiquées ci-dessus.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.
