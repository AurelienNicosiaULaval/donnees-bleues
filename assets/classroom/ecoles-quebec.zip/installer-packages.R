# À exécuter une fois avec Internet avant la séance.
packages <- c("digest", "dplyr", "ggplot2", "httr2", "jsonlite", "readr", "xml2")
absents <- setdiff(packages, rownames(installed.packages()))
if (length(absents)) install.packages(absents, repos = "https://cloud.r-project.org")
stopifnot(all(vapply(packages, requireNamespace, logical(1), quietly = TRUE)))
