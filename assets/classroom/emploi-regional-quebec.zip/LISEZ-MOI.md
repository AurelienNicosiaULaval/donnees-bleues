# Emploi régional au Québec

Les données ISQ ne sont pas incluses. Après lecture des conditions de la source, ouvrir preparer-donnees.R et cliquer Source avec Internet avant la séance. Les CSV seront créés sur votre ordinateur. Ne pas redistribuer ces CSV sans autorisation applicable.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Ouvrir preparer-donnees.R et cliquer Source avec Internet.
5. Ouvrir datasets/emploi-regional-quebec/activite-courte.R ou activite-longue.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://aureliennicosiaulaval.github.io/donnees-bleues/datasets/emploi-regional-quebec/fiche.html

## Source et réutilisation

Producteur : Institut de la statistique du Québec / Statistique Canada, Enquête sur la population active
Source : https://statistique.quebec.ca/fr/document/population-active-emploi-et-chomage-regions-administratives-rmr-et-quebec
Conditions : https://statistique.quebec.ca/fr/institut/nous-joindre/droits-auteur-permission-reproduction
Préparation : 2026-09-05T11:04:35Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.

Les licences des producteurs tiers s’appliquent à leurs données. Voir la page À propos du site pour les conditions propres aux textes et au code de Données bleues.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.
