## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

VILLE DE MONTRÉAL. Arbres publics sur le territoire de la Ville, [Jeu de données], dans Données Québec, 2020, mis à jour le 10 novembre 2026. [https://www.donneesquebec.ca/recherche/dataset/vmtl-arbres], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/vmtl-arbres).
