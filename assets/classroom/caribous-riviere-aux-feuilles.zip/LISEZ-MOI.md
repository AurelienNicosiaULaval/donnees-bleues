# Caribous de la Rivière-aux-Feuilles

Les CSV préparés sont inclus. Le script fonctionne hors ligne après installation des packages.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Conserver les sous-dossiers de données à leur place.
5. Ouvrir datasets/caribous-riviere-aux-feuilles/activite-intervalles.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://aureliennicosiaulaval.github.io/donnees-bleues/datasets/caribous-riviere-aux-feuilles/fiche.html

## Source et réutilisation

Producteur : Leblond, St-Laurent et Côté; dépôt Dryad et copie publique Zenodo
Source : https://datadryad.org/dataset/doi:10.5061/dryad.4k275
Conditions : https://creativecommons.org/publicdomain/zero/1.0/
Attributions et documentation incluses : datasets/caribous-riviere-aux-feuilles/DATA_LICENSE.md, datasets/caribous-riviere-aux-feuilles/DICTIONNAIRE.md, datasets/caribous-riviere-aux-feuilles/README.md.
Préparation : 2026-10-08T18:02:50Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.

Le code original de Données bleues est sous licence MIT (voir LICENSE). Les textes et activités originales sont sous CC BY 4.0 (voir LICENCE-CONTENUS.md). Les données et autres contenus de tiers conservent les conditions de leurs producteurs indiquées ci-dessus.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.
