# À exécuter une fois avec Internet avant la séance.
packages <- c("curl", "digest", "dplyr", "ggplot2", "jsonlite", "readr", "readxl", "tidyr")
absents <- setdiff(packages, rownames(installed.packages()))
if (length(absents)) install.packages(absents, repos = "https://cloud.r-project.org")
stopifnot(all(vapply(packages, requireNamespace, logical(1), quietly = TRUE)))
