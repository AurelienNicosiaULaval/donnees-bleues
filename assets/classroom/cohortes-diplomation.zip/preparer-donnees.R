# Connexion requise. Consulter les conditions de la source avant utilisation.
# https://statistique.quebec.ca/fr/institut/nous-joindre/droits-auteur-permission-reproduction
source("datasets/cohortes-diplomation/preparation.R")
