## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

MINISTÈRE DE L'ENVIRONNEMENT, DE LA LUTTE CONTRE LES CHANGEMENTS CLIMATIQUES, DE LA PROTECTION DE LA BIODIVERSITÉ, DE LA FAUNE ET DES PARCS. RSQAQ - Stations de la qualité de l'air, [Jeu de données], dans Données Québec, 2022, mis à jour le 16 octobre 2026. [https://www.donneesquebec.ca/recherche/dataset/rsqaq-stations], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/rsqaq-stations).
