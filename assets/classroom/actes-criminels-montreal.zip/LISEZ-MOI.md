# Actes criminels enregistrés à Montréal

Les CSV préparés sont inclus. Le script fonctionne hors ligne après installation des packages.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Conserver les sous-dossiers de données à leur place.
5. Ouvrir datasets/actes-criminels-montreal/activite-courte.R ou activite-longue.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://donneesbleues.ca/datasets/actes-criminels-montreal/fiche.html

## Source et réutilisation

Producteur : Données Québec / Ville de Montréal / SPVM
Source : https://www.donneesquebec.ca/recherche/dataset/vmtl-actes-criminels
Conditions : https://creativecommons.org/licenses/by/4.0/deed.fr
Préparation : 2026-09-05T11:04:29Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.

Le code original de Données bleues est sous licence MIT (voir LICENSE). Les textes et activités originales sont sous CC BY 4.0 (voir LICENCE-CONTENUS.md). Les données et autres contenus de tiers conservent les conditions de leurs producteurs indiquées ci-dessus.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.





## Acquisition par API et citations

Les références recommandées par Données Québec figurent dans CITATIONS.md. Les dates des copies utilisées dans les exercices restent celles de provenance.json.

Pour acquérir une nouvelle source, ouvrir acquerir-donnees-quebec.R avec Internet. Une première exécution affiche les ressources; renseigner ensuite resource_id. Le script utilise DataStore lorsque la ressource est interrogeable; sinon il télécharge la ressource repérée par l’API du catalogue.

Les nouvelles sources sont placées dans un dossier daté distinct. Elles ne remplacent pas les CSV fournis. Les transformations pédagogiques restent à appliquer avant une nouvelle analyse. Les colonnes et les valeurs de l’API peuvent différer de celles du fichier téléchargeable.
