# À exécuter une fois avec Internet avant la séance.
packages <- c("dplyr", "ggplot2", "readr")
absents <- setdiff(packages, rownames(installed.packages()))
if (length(absents)) install.packages(absents, repos = "https://cloud.r-project.org")
stopifnot(all(vapply(packages, requireNamespace, logical(1), quietly = TRUE)))
