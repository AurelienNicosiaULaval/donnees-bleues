## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

MINISTÈRE DES AFFAIRES MUNICIPALES ET DE L'HABITATION. Profil financier des municipalités locales, [Jeu de données], dans Données Québec, 2024, mis à jour le 07 novembre 2026. [https://www.donneesquebec.ca/recherche/dataset/profil-financier-des-municipalites-locales], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/profil-financier-des-municipalites-locales).
