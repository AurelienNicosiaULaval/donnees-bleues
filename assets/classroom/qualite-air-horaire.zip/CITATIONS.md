## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

MINISTÈRE DE L’ENVIRONNEMENT, DE LA LUTTE CONTRE LES CHANGEMENTS CLIMATIQUES, DE LA FAUNE ET DES PARCS. RSQAQ - Données horaires continues, [Jeu de données], dans Données Québec, 2022, mis à jour le 22 juin 2026. [https://www.donneesquebec.ca/recherche/dataset/rsqaq-donnees-horaires-continues], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/rsqaq-donnees-horaires-continues).
