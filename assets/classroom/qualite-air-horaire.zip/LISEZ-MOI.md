# Qualité de l'air au Québec

Les CSV préparés sont inclus. Le script fonctionne hors ligne après installation des packages.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Conserver les sous-dossiers de données à leur place.
5. Ouvrir datasets/qualite-air-horaire/activite-courte.R ou activite-longue.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://aureliennicosiaulaval.github.io/donnees-bleues/datasets/qualite-air-horaire/fiche.html

## Source et réutilisation

Producteur : Données Québec / MELCCFP / RSQAQ
Source : https://www.donneesquebec.ca/recherche/dataset/rsqaq-donnees-horaires-continues
Conditions : https://creativecommons.org/licenses/by/4.0/deed.fr
Préparation : 2026-09-05T12:46:41Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.
RSQAQ : heures publiées en HNE (UTC-5 fixe), à la fin de l’intervalle. Les résumés portent sur le jour HNE du début de cet intervalle. Seuls les jours de 2025 sont retenus; la fin du fichier annuel peut donner une couverture partielle du dernier jour. Les PM2,5-T640 sont en µg/m³.

Les licences des producteurs tiers s’appliquent à leurs données. Voir la page À propos du site pour les conditions propres aux textes et au code de Données bleues.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.
