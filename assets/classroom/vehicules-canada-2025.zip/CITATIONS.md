## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

SOCIÉTÉ DE L'ASSURANCE AUTOMOBILE DU QUÉBEC (SAAQ). Véhicules en circulation, [Jeu de données], dans Données Québec, 2017, mis à jour le 18 décembre 2023. [https://www.donneesquebec.ca/recherche/dataset/vehicules-en-circulation], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/vehicules-en-circulation).
