# Rapports d'accident

Les CSV préparés sont inclus. Le script fonctionne hors ligne après installation des packages.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Conserver les sous-dossiers de données à leur place.
5. Ouvrir datasets/rapports-accident/activite-courte.R ou datasets/rapports-accident/activite-longue.R ou datasets/rapports-accident/activite-permutation.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://donneesbleues.ca/datasets/rapports-accident/fiche.html

La table de classe initiale est conservée. Pour utiliser la copie API incluse sans Internet, ouvrir datasets/rapports-accident/rejouer-api.R et cliquer Source. Pour acquérir une nouvelle copie, utiliser actualiser-api.R avec Internet. Ensuite, exécuter l’activité dans la même session R.

## Source et réutilisation

Producteur : Données Québec / Société de l'assurance automobile du Québec
Source : https://www.donneesquebec.ca/recherche/dataset/rapports-d-accident
Conditions : https://creativecommons.org/licenses/by/4.0/deed.fr
Préparation : 2026-10-03T13:51:00Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.

Le code original de Données bleues est sous licence MIT (voir LICENSE). Les textes et activités originales sont sous CC BY 4.0 (voir LICENCE-CONTENUS.md). Les données et autres contenus de tiers conservent les conditions de leurs producteurs indiquées ci-dessus.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.
