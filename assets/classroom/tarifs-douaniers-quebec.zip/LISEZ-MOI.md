# Tarifs douaniers, prix et commerce au Québec

Les CSV préparés sont inclus. Le script fonctionne hors ligne après installation des packages.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Conserver les sous-dossiers de données à leur place.
5. Ouvrir datasets/tarifs-douaniers-quebec/activite-lire-tarifs.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://aureliennicosiaulaval.github.io/donnees-bleues/datasets/tarifs-douaniers-quebec/fiche.html

## Source et réutilisation

Producteur : Sources fédérales officielles; compilation Données bleues
Source : https://doi.org/10.25318/1210017501-fra
Conditions : https://donneesbleues.ca/datasets/tarifs-douaniers-quebec/downloads/20261005T200817Z/DATA_LICENSE.md
Attributions et documentation incluses : datasets/tarifs-douaniers-quebec/DATA_LICENSE.md, datasets/tarifs-douaniers-quebec/DICTIONNAIRE.md, datasets/tarifs-douaniers-quebec/README.md.
Préparation : 2026-10-05T20:08:18Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.

Le code original de Données bleues est sous licence MIT (voir LICENSE). Les textes et activités originales sont sous CC BY 4.0 (voir LICENCE-CONTENUS.md). Les données et autres contenus de tiers conservent les conditions de leurs producteurs indiquées ci-dessus.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.
