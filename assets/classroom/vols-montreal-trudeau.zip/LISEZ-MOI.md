# Trajectoires aériennes observées à Montréal-Trudeau (YUL)

Les CSV préparés sont inclus. Le script fonctionne hors ligne après installation des packages.

1. Extraire tout le ZIP dans un dossier.
2. Double-cliquer sur Donnees-bleues.Rproj pour ouvrir RStudio.
3. Avant la séance, ouvrir installer-packages.R et cliquer Source avec Internet.
4. Conserver les sous-dossiers de données à leur place.
5. Ouvrir datasets/vols-montreal-trudeau/activite-courte.R, puis cliquer Source.
6. Lire les tableaux dans Console et les graphiques dans Plots. Les consignes propres à chaque activité sont sur le site.

Activités : https://aureliennicosiaulaval.github.io/donnees-bleues/datasets/vols-montreal-trudeau/fiche.html

## Source et réutilisation

Producteur : MrAirspace, archives de trajectoires issues d'ADSB.lol; adaptation YUL par Aurélien Nicosia
Source : https://github.com/MrAirspace/aircraft-flight-schedules
Conditions : https://github.com/MrAirspace/aircraft-flight-schedules/blob/main/LICENSE-ODbL.txt
Attributions et documentation incluses : datasets/vols-montreal-trudeau/DATA-LICENSE.md, datasets/vols-montreal-trudeau/METHODE.md.
Préparation : 2026-09-23T22:30:53Z (UTC). Les dates de chaque acquisition figurent dans provenance.json.
Transformation : préparation par Données bleues, puis sélection des colonnes déclarées. Les observations et résumés reflètent cet instantané; ils ne sont pas actualisés par les scripts d’activité.
Lors d’une réutilisation, conserver l’attribution au producteur, le lien vers la source, les conditions et la date de préparation. Mentionner vos modifications.

Le code original de Données bleues est sous licence MIT (voir LICENSE). Les textes et activités originales sont sous CC BY 4.0 (voir LICENCE-CONTENUS.md). Les données et autres contenus de tiers conservent les conditions de leurs producteurs indiquées ci-dessus.

## Vérification

provenance.json décrit les tables, colonnes, versions testées et sources. SHA256SUMS donne l’empreinte des fichiers contenus dans cette trousse.
