## Références Données Québec

Citations des fiches officielles consultées à la date indiquée. Cette vérification documentaire ne constitue pas une nouvelle acquisition des données; les dates des fichiers et leurs transformations figurent dans les notices de provenance.

MINISTÈRE DES RESSOURCES NATURELLES ET DES FORÊTS. Géobase du réseau hydrographique du Québec (GRHQ), [Jeu de données], dans Données Québec, 2019, mis à jour le 09 octobre 2026. [https://www.donneesquebec.ca/recherche/dataset/grhq], (consulté le 10 novembre 2026).

Licence de la fiche consultée : Attribution (CC-BY 4.0). [Fiche officielle](https://www.donneesquebec.ca/recherche/dataset/grhq).
